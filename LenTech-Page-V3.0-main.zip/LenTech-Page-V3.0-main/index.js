const user = JSON.parse(localStorage.getItem('login_success')) || false;

if (!user) {
    // Si el usuario no está logueado, muestra la alerta de SweetAlert
    Swal.fire({
        icon: 'info',
        title: 'Iniciar Sesión',
        text: 'Debes iniciar sesión para acceder a esta página',
        confirmButtonText: 'Ir a Iniciar Sesión',
        showCancelButton: false,
        allowOutsideClick: false
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'login.html'; // Redirigir a la página de login
        }
    });
} else {
    // Oculta los botones de Signup y Login si el usuario está logueado
    const signupLink = document.querySelector('#signup');
    const loginLink = document.querySelector('#login');
    signupLink.style.display = 'none';
    loginLink.style.display = 'none';

    // Muestra el nombre del usuario y el ícono al lado del carrito
    const userIcon = document.createElement('span');
    userIcon.classList.add('user-info'); // Añade la clase para el estilo
    userIcon.innerHTML = `
        
        <span>${user.name}</span> <!-- Asegúrate de que el nombre esté almacenado en localStorage -->
    `;

    // Inserta el ícono de usuario junto al carrito
    const cartLink = document.querySelector('.cart-link');
    cartLink.insertAdjacentElement('afterend', userIcon);
}

// Lógica para el cierre de sesión
const logout = document.querySelector('#logout');
logout.addEventListener('click', () => {
    Swal.fire({
        icon: 'info',
        title: 'Cerrar Sesión',
        text: '¿Estás seguro de que queires cerrar sesión?',
        showCancelButton: true,
        confirmButtonText: 'Sí, cerrar sesión',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            localStorage.removeItem('login_success'); // Eliminar la sesión del localStorage
            Swal.fire({
                icon: 'success',
                title: 'Sesión Cerrada',
                text: 'Tu sesión ha sido cerrada correctamente.',
                confirmButtonText: 'OK'
            }).then(() => {
                window.location.href = 'login.html'; // Redirigir a la página de login después de cerrar sesión
            });
        }
    });
});
